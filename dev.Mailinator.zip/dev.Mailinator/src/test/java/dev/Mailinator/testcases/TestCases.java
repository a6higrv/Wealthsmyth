package dev.Mailinator.testcases;

import java.io.File;
import java.io.FileInputStream;
import java.time.Duration;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestCases {

	public String baseUrl = "https://dev.wealthsmyth.ai/";
	public WebDriver driver;

	@BeforeTest
	public void login() throws InterruptedException {
		System.out.println("Entered Login method");
		System.out.println("Before Test executed");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(baseUrl);
		WebElement LogIn = driver.findElement(By.xpath("//button[contains(text(),'Log In')]"));
		LogIn.click();

		Thread.sleep(2000);

		WebElement email = driver.findElement(By.id("email"));
		email.click();
		email.sendKeys("madisonhenry@mailinator.com");

		Thread.sleep(2000);

		WebElement pass = driver.findElement(By.id("password"));
		pass.click();
		pass.sendKeys("P@ssword12345");

		Thread.sleep(2000);

		WebElement submitButton = driver.findElement(By.xpath("//button[contains(text(),'Log In')]"));
		submitButton.submit();
		System.out.println("Test Case 1:Login Successfull");

		Thread.sleep(1000);

		////////////////////////////////////////////////////////////////////////////////

		WebDriverWait waitforuser = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement henry = waitforuser.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//h4[@class='text-[28px] font-semibold cursor-pointer']")));
		//////////////////////////////////////////////////////////////////////////////

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", henry);

		System.out.println("JavaScript click Pass: ");

		///////////////////////////////////////////////////////////////////////////////////

		// wait till load
		WebDriverWait waitForWindow = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement window = waitForWindow.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(
				"div[class='font-semibold font-inter px-[30px] py-4 cursor-pointer text-[#3A4253] text-[16px] flex gap-3 items-center']")));
		window.click();

		////////////////////////////////////////////////////////////////////////////////////////

		WebElement element1 = driver.findElement(By.cssSelector(
				"body div[id='root'] div[class='flex flex-col'] div[class='flex flex-col'] div:nth-child(2) div:nth-child(1) div:nth-child(1) svg"));
		element1.click();

		WebElement element2 = driver.findElement(By.xpath("//div[contains(text(),'Contact Information')]"));
		element2.click();

		// for till element it will scroll
		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("arguments[0].scrollIntoView(true);", element1);

		js2.executeScript("window.scrollTo(0, 0)");

		////////////////////////////////////////////////////////////////////////////////////////

		Thread.sleep(3000);

		/////////////////////////////////////////////////////////////////////////////////////////

		WebElement char_john = driver.findElement(By.cssSelector(
				"body > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > aside:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(3) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > p:nth-child(2)"));
		char_john.click();

//				WebElement char_john_window = driver.findElement(By.cssSelector(
//						"body > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(2) > div:nth-child(1) > h4:nth-child(1)"));
//				char_john_window.click();
//				

		WebElement element = new WebDriverWait(driver, Duration.ofSeconds(20))
				.until(ExpectedConditions.elementToBeClickable(By.cssSelector(
						"body > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(2) > div:nth-child(1) > h4:nth-child(1)")));
		element.click();

		////////////////////////////////////////////////////////////////////////////////////////

		Thread.sleep(3000);

		WebDriverWait waitkaur = new WebDriverWait(driver, Duration.ofSeconds(20));

		// Wait for the first element to be clickable and then click it
		WebElement ranvit_Kaur = waitkaur.until(ExpectedConditions.elementToBeClickable(By.cssSelector(
				"body > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > aside:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(4) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > p:nth-child(2)")));
		ranvit_Kaur.click();

		// Wait for the second element to be clickable and then click it
		WebElement ranvit_Kaur_window = waitkaur.until(ExpectedConditions.elementToBeClickable(By.cssSelector(
				"body > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(3) > div:nth-child(2) > div:nth-child(1) > h4:nth-child(1)")));
		ranvit_Kaur_window.click();

		WebDriverWait waitclose = new WebDriverWait(driver, Duration.ofSeconds(20));

		// Wait until the button with the specified XPath is visible and then click it
		WebElement button = waitclose.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='w-6 h-6']//*[name()='svg']")));
		button.click();
		System.out.println("Test Case 2: HomeScreen Users Validated");
	}

	@Test(priority = 1)
	public void profile() throws InterruptedException {
		System.out.println("Entered Profile section method");
		System.out.println("Test Case 3: Profile Section Opened");

		System.out.println("PASSED: dev.Mailinator.testcases.TestCases.Login");
		// NOW IM MOVING TO PROFILE & SETTING OPTIONS
		WebElement profileTab = driver.findElement(By.cssSelector("nav[id='nav-bar'] span:nth-child(1)"));
		profileTab.click();

		Thread.sleep(4000);

		// NOW CLICK IN PROFILE SETTING
		WebDriverWait wait_for_profilesetting = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement profilesection = wait_for_profilesetting.until(ExpectedConditions.elementToBeClickable(By.xpath(
				"//li[contains(@class,'font-medium font-inter px-6 py-4 mt-2 cursor-pointer text-gray-600 hover:bg-green-400 text-base hover:text-white')]")));
		profilesection.click();

		Thread.sleep(4000);
		// EDIT THE PROFILE
//				WebDriverWait wait_personalinfo_edit = new WebDriverWait(driver, Duration.ofSeconds(20));
//				WebElement profilesectionOpen = wait_personalinfo_edit.until(ExpectedConditions
//						.elementToBeClickable(By.xpath("//img[@class='mr-5 w-[20px] h-[20px]']")));
//				profilesectionOpen.click();

		WebDriverWait wait_personalinfo_edit = new WebDriverWait(driver, Duration.ofSeconds(20));

		// Wait until the element is visible and clickable
		WebElement profilesectionOpen = wait_personalinfo_edit.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//img[@class='mr-5 w-[20px] h-[20px]']")));

		// Scroll the element into view
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", profilesectionOpen);
		// Ensure the element is clickable
		WebElement clickableElement = wait_personalinfo_edit
				.until(ExpectedConditions.elementToBeClickable(profilesectionOpen));

		// Click the element
		clickableElement.click();

		WebElement lastname = wait_personalinfo_edit
				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@name,'Last_name')]")));
		lastname.click();
		lastname.sendKeys("");

		WebElement PersonalsaveButton = driver.findElement(By.xpath("//button[@type='submit']"));
		PersonalsaveButton.click();

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", PersonalsaveButton);

		JavascriptExecutor js2 = (JavascriptExecutor) driver;
		js2.executeScript("arguments[0].click();", PersonalsaveButton);

		/////////////////////////
		// PUT TO ORIGINAL AS HENRY

		// WebDriverWait wait_original = new WebDriverWait(driver,
		// Duration.ofSeconds(20));
//		    		WebElement Editpen = wait_original.until(
//		    				ExpectedConditions.elementToBeClickable(By.xpath("//img[@class='mr-5 w-[20px] h-[20px]']")));
//		    		Editpen.click();
//
//		    		WebElement lastname_original = wait_original
//		    				.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@name,'Last_name')]")));
//		    		lastname_original.click();
//		    		lastname_original.clear();
//		    		lastname_original.sendKeys("Henry");

		/*
		 * // Wait for the Edit pen icon to be clickable WebElement Editpen =
		 * wait_original.until(ExpectedConditions.elementToBeClickable(By.
		 * xpath("//img[@class='mr-5 w-[20px] h-[20px]']")));
		 * 
		 * // Scroll the Editpen element into view before clicking (if it's out of view)
		 * JavascriptExecutor js5 = (JavascriptExecutor) driver;
		 * js5.executeScript("arguments[0].scrollIntoView(true);", Editpen);
		 * 
		 * // Additional wait to ensure the element is not covered by other elements
		 * wait_original.until(ExpectedConditions.visibilityOf(Editpen));
		 * 
		 * // Check if the element is enabled and clickable again after scrolling into
		 * view if (Editpen.isDisplayed() && Editpen.isEnabled()) { // Click on the Edit
		 * pen icon Editpen.click(); } else {
		 * System.out.println("Edit pen icon is not clickable."); }
		 * 
		 * // Wait for the Lastname input field to be visible WebElement
		 * lastname_original =
		 * wait_original.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
		 * "//input[contains(@name,'Last_name')]")));
		 * 
		 * // Clear and enter the new last name lastname_original.click();
		 * lastname_original.clear(); lastname_original.sendKeys("Henry");
		 * 
		 * 
		 * 
		 * 
		 * WebElement saveButton_original =
		 * driver.findElement(By.xpath("//button[@type='submit']"));
		 * saveButton_original.click();
		 * 
		 * JavascriptExecutor js3 = (JavascriptExecutor) driver;
		 * js3.executeScript("arguments[0].click();", saveButton_original);
		 * 
		 * JavascriptExecutor js4 = (JavascriptExecutor) driver;
		 * js4.executeScript("arguments[0].click();", saveButton_original);
		 */

	}

	@Test(priority = 2, enabled = true)
	public void Teams() throws InterruptedException {

		System.out.println("Entered Team_add method");
		System.out.println("Entered Team_invite method");
		driver.get("https://dev.wealthsmyth.ai/agent/Mw%3D%3D");
		driver.navigate().to("https://dev.wealthsmyth.ai/dashboard");
		
		driver.navigate().refresh();
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		// Locate the button
		WebElement newTeamMember = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'New Team Member')]")));

		// Perform JavaScript click
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", newTeamMember);

		System.out.println("JavaScript click executed.");

		Thread.sleep(10000);
		
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		
		
		WebElement contract_level = driver.findElement(By.xpath("//div[contains(text(),'Select Contract Level')]"));
		contract_level.click();
		
		Thread.sleep(5000);
		
		WebElement selectLevel = driver.findElement(By.xpath("//li[contains(text(),'Representative')]"));
		selectLevel.click();
		
		Thread.sleep(6000);
		
		WebElement provider = driver.findElement(By.xpath("//input[@placeholder='Select Provider']"));
		provider.click();
		provider.sendKeys(Keys.ARROW_DOWN); // Press the down arrow to navigate
		Thread.sleep(1000); // Small pause for the dropdown to react

		provider.sendKeys(Keys.ENTER); 
		
		Thread.sleep(5000);
		

//		WebElement selectProvider1 = driver.findElement(By.xpath("//*[@id=\"new-team-form\"]/div[1]/div[2]/div/div/div/input"));
//		selectProvider1.click();
		
		Thread.sleep(3000);
		
		
		
		WebElement first = driver.findElement(By.xpath("//input[@id='firstName']"));
		first.sendKeys("Rajendra");
		Thread.sleep(2000);
		
		WebElement last = driver.findElement(By.xpath("//input[@id='lastName']"));
		last.sendKeys("Rane");
		
		Thread.sleep(3000);
		
		driver.findElement(By.id("agentId")).sendKeys("T9734");
		Thread.sleep(1000);
		driver.findElement(By.id("npn")).sendKeys("19044");
		Thread.sleep(1000);
		driver.findElement(By.id("emailAddress")).sendKeys("rajrane43@mailinator.com");
		Thread.sleep(1000);
		
		WebElement country = driver.findElement(By.xpath("//select[contains(@name,'MobileCountry')]"));

		country.click();
		
		Thread.sleep(7000);
		
		Select se1 = new Select(country);
		se1.selectByVisibleText("India");
		
		Thread.sleep(1000);
		
		WebElement type_number = driver.findElement(By.xpath("//input[@placeholder='Enter phone number']"));
		type_number.click();
		type_number.sendKeys("7787902341");
		
		Thread.sleep(2000);
		
		WebElement create_team_member = driver
				.findElement(By.xpath("//button[contains(text(),'Create Team Member')]"));
		create_team_member.click();
		Thread.sleep(10000);
		
		System.out.println("Test Case 4:User Added to Team");


	}
	
	@Test(priority=3)
	public void team_invite() throws InterruptedException {
		System.out.println("Entered Team_invite method");
		driver.get("https://dev.wealthsmyth.ai/agent/Mw%3D%3D");
		driver.navigate().to("https://dev.wealthsmyth.ai/dashboard");
		
		driver.navigate().refresh();
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		// Locate the button
		WebElement newTeamMember = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//button[contains(text(),'New Team Member')]")));

		// Perform JavaScript click
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", newTeamMember);

		System.out.println("JavaScript click executed.");

		Thread.sleep(11000);
		
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		
		
		WebElement contract_level = driver.findElement(By.xpath("//div[contains(text(),'Select Contract Level')]"));
		contract_level.click();
		
		Thread.sleep(5000);
		
		WebElement selectLevel = driver.findElement(By.xpath("//li[contains(text(),'Representative')]"));
		selectLevel.click();
		
		Thread.sleep(8000);
		
		WebElement provider = driver.findElement(By.xpath("//input[@placeholder='Select Provider']"));
		provider.click();
		
		Thread.sleep(5000);
		
		provider.sendKeys(Keys.ARROW_DOWN); // Press the down arrow to navigate
		Thread.sleep(1000); // Small pause for the dropdown to react

		provider.sendKeys(Keys.ENTER); 
		
//		Thread.sleep(5000);
		Thread.sleep(8000);
		
		
		
		WebElement first = driver.findElement(By.xpath("//input[@id='firstName']"));
		first.sendKeys("Darshanaya");
		Thread.sleep(4000);
		
		WebElement last = driver.findElement(By.xpath("//input[@id='lastName']"));
		last.sendKeys("Gawade");
		
		Thread.sleep(3000);
		
		driver.findElement(By.id("agentId")).sendKeys("T9631");
		Thread.sleep(1000);
		driver.findElement(By.id("npn")).sendKeys("20017");
		Thread.sleep(1000);
		driver.findElement(By.id("emailAddress")).sendKeys("gawadedarsh35@mailinator.com");
		Thread.sleep(1000);
		
		WebElement country = driver.findElement(By.xpath("//select[contains(@name,'MobileCountry')]"));

		country.click();
		
		Thread.sleep(7000);
		
		Select se1 = new Select(country);
		se1.selectByVisibleText("India");
		
		Thread.sleep(1000);
		
		WebElement type_number = driver.findElement(By.xpath("//input[@placeholder='Enter phone number']"));
		type_number.click();
		type_number.sendKeys("7787902342");
		
		Thread.sleep(2000);
		
		WebElement create_team_member = driver
				.findElement(By.xpath("//button[contains(text(),'Create Team Member')]"));
		create_team_member.click();
		Thread.sleep(10000);
		
		WebElement invite = driver.findElement(
				By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody[1]/tr[1]/td[7]/div[1]/*[name()='svg'][1]"));
		invite.click();
		
		Thread.sleep(10000);
		
		WebElement invitebyemail = driver
				.findElement(By.cssSelector("li[class='border-0 text-[#6B7280] px-4 py-2 hover:bg-[#2BB574] hover:text-white cursor-pointer font-semibold']"));
		invitebyemail.click();
		
		Thread.sleep(7000);
	
		
		System.out.println("Test Case 5:User added in Team and Invited via Mail");
	}

	@Test(priority=4)
	public void search() throws InterruptedException {
		System.out.println("Entered search method");
		driver.get("https://dev.wealthsmyth.ai/agent/Mw%3D%3D");
		driver.navigate().to("https://dev.wealthsmyth.ai/dashboard");
		
		driver.navigate().refresh();
		
		Thread.sleep(10000);

		WebDriverWait explicitWait = new WebDriverWait(driver, Duration.ofSeconds(15));

		// Wait until the search input field is visible
		WebElement searchInputField = explicitWait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@placeholder='Search Team Member']")));

		// Click the search field
		searchInputField.click();

		// Enter the search text
		searchInputField.sendKeys("Darshan");

		// Press Enter key
		searchInputField.sendKeys(Keys.ENTER);
		
		Thread.sleep(7000);
		
		// Wait until the desired user is located and click on it
		WebElement userElement = explicitWait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Darshan Gawade (T9615)']")));
		userElement.click();
		
		Thread.sleep(10000);
		
		// Initialize WebDriverWait with a timeout of 15 seconds
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		
		// Wait until the detailsArrow element is visible and clickable
		WebElement notesArrow = wait.until(ExpectedConditions.elementToBeClickable(
		    By.xpath("//div[@id='root']/div/div/div[2]/div[1]/div/div/div[3]/div[1]/div/div")));

		// Click the detailsArrow element
		notesArrow.click();
		
		Thread.sleep(10000);
		
		// Initialize WebDriverWait with a timeout of 15 seconds
		WebDriverWait waitForEditButton = new WebDriverWait(driver, Duration.ofSeconds(15));

		// Wait until the editButton element is visible and clickable
		WebElement editButton = waitForEditButton.until(ExpectedConditions.elementToBeClickable(
		    By.xpath("//div[@class='cursor-pointer hover:bg-slate-100 rounded-full']//img[@alt='edit']")));

		// Click the editButton element
		editButton.click();

		// Print confirmation
		System.out.println("Edit button clicked.");
		
		Thread.sleep(5000);
		
		// Initialize WebDriverWait with a timeout of 15 seconds
		WebDriverWait waitForCloseButton = new WebDriverWait(driver, Duration.ofSeconds(15));

		// Wait until the closeButton element is visible and clickable
		WebElement closeButton = waitForCloseButton.until(ExpectedConditions.elementToBeClickable(
		    By.xpath("//div[@class='absolute bg-[#4871B7] w-[2px] h-full -rotate-45']")));

		// Click the closeButton element
		closeButton.click();

		// Print confirmation
		System.out.println("Close button clicked.");
		
		Thread.sleep(5000);
		
		// Define the element's XPath
		By targetElementLocator = By.xpath("//div[@id='root']/div/div/div[2]/div[1]/div/div/div[3]/div[2]/div/div");

		// Create WebDriverWait with a 20-second timeout
		WebDriverWait explicitWait1 = new WebDriverWait(driver, Duration.ofSeconds(20));

		// Wait for the element to be present
		WebElement targetElement = explicitWait1.until(ExpectedConditions.presenceOfElementLocated(targetElementLocator));

		// Scroll to the element using JavaScript
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
		jsExecutor.executeScript("arguments[0].scrollIntoView(true);", targetElement);

		// Wait for the element to be visible after scrolling
		explicitWait1.until(ExpectedConditions.visibilityOf(targetElement));

		// Now you can interact with the element
		targetElement.click();  // Example action
		
		Thread.sleep(3000);
		
		// Locate the edit button element
		WebElement editButtonElement = driver.findElement(By.xpath("//div[@id='root']/div/div/div[2]/div[1]/div/div/div[3]/div[2]/div[1]/div[2]/div/img"));

		// Scroll to the element using JavaScript
		JavascriptExecutor javascriptExecutor = (JavascriptExecutor) driver;
		javascriptExecutor.executeScript("arguments[0].scrollIntoView({ behavior: 'smooth', block: 'center' });", editButtonElement);

		// Optionally, wait for the element to become interactable
		WebDriverWait explicitWait11 = new WebDriverWait(driver, Duration.ofSeconds(10));
		explicitWait11.until(ExpectedConditions.elementToBeClickable(editButtonElement));

		// Perform the click action
		editButtonElement.click();
		
		Thread.sleep(4000);

		
	}

	@Test(priority = 5)
	public void change_password() throws InterruptedException {

		System.out.println("Entered Change password method");
		driver.get("https://dev.wealthsmyth.ai/agent/Mw%3D%3D");

		// NOW IM MOVING TO PROFILE & SETTING OPTIONS
		WebElement profileTab = driver.findElement(By.cssSelector("nav[id='nav-bar'] span:nth-child(1)"));
		profileTab.click();

		Thread.sleep(4000);

		// NOW CLICK IN PROFILE SETTING
		WebDriverWait wait_for_change = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement profilesection = wait_for_change
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//li[normalize-space()='Change Password']")));
		profilesection.click();

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		// Wait for the new password textbox to appear
		By newPasswordLocator = By.xpath("//input[@id='password']");
		WebElement newPasswordTextbox = wait.until(ExpectedConditions.visibilityOfElementLocated(newPasswordLocator));

		// Enter new password
		newPasswordTextbox.sendKeys("NewPassword123");
		
		System.out.println("New password entered.");
		
		Thread.sleep(2000);

		// Wait for the repeat password textbox to appear
		By repeatPasswordLocator = By.xpath("//input[@id='confirmPassword']");
		WebElement repeatPasswordTextbox = wait
				.until(ExpectedConditions.visibilityOfElementLocated(repeatPasswordLocator));

		// Enter repeat password
		repeatPasswordTextbox.sendKeys("NewPassword123");
		System.out.println("Repeat password entered.");
		Thread.sleep(3000);

		// Click the Reset Password button
		By resetPasswordButtonLocator = By.xpath("//button[@type='submit']");
		WebElement resetPasswordButton = wait
				.until(ExpectedConditions.elementToBeClickable(resetPasswordButtonLocator));
//	        resetPasswordButton.click();
		Thread.sleep(2000);
		System.out.println("Reset Password button clicked.");
		System.out.println("TestCase 6: Changed Password");

	}

	@Test(priority = 6)
	public void logout() {
		System.out.println("Entered Logout method");
		driver.get("https://dev.wealthsmyth.ai/agent/Mw%3D%3D");
		try {
			// Define Locator
			By panelTriggerLocator = By.xpath("//img[contains(@alt,'User')]");

			// Wait for the element to appear and be clickable
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
			WebElement panelTrigger = wait.until(ExpectedConditions.presenceOfElementLocated(panelTriggerLocator));

			// Ensure the element is visible
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", panelTrigger);
			wait.until(ExpectedConditions.visibilityOf(panelTrigger));

			// Perform the click
			try {
				panelTrigger.click();
			} catch (Exception e) {
				System.out.println("Click failed, trying JavaScript Executor...");
				((JavascriptExecutor) driver).executeScript("arguments[0].click();", panelTrigger);
			}

			System.out.println("Side panel opened.");

			// Wait for the logout button inside the panel
			By logoutButtonLocator = By.xpath(
					"//div[@class='font-medium font-inter px-6 py-4 cursor-pointer text-neutral-600 hover:bg-green-400 text-base hover:text-white']"); // Adjust
																																						// the
			Thread.sleep(3000); // locator
			WebElement logoutButton = wait.until(ExpectedConditions.elementToBeClickable(logoutButtonLocator));

			// Scroll into view (optional, if necessary)
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", logoutButton);

			// Click the logout button
			logoutButton.click();
			Thread.sleep(2000);
			System.out.println("Logout button clicked.");

		} catch (Exception e) {
		}

		System.out.println("Test Case 7: User Logged out");
		driver.quit();
	}

}
